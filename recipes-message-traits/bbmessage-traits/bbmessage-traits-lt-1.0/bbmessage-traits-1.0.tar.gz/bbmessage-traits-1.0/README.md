## Message Traits
Type traits made easy for message dispatching.

## Building
docker build -t message_traits .
